let candidatos = [
    {título: 'VEREADOR', digitos: 5, todos: [{nome:'Jeca Tatu', partido:'aleatório', numero: '12345', img: 'img/12345.jpg'}, {nome:'Soneca', partido:'pp', numero: '38111', img: 'img/38111.jpg'}]},

    {título: 'PREFEITO', digitos: 2, todos:[{nome:'Maximus II', partido:'partido das trevas', numero: '99', img: 'img/99.jpg', vice:{nome:'Nevão', img: 'img/99_2.jpg'}},{nome:'Jeremias', partido:'politicos da depressão', numero: '84', img: 'img/84.jpg', vice:{nome:'Kevinho', img: 'img/84_2.jpg'}}]}
];